import msgpackDecode from './msgpack/decode';
import msgpackEncode from './msgpack/encode';
export declare const decode: typeof msgpackDecode;
export declare const encode: typeof msgpackEncode;
