/**
 * Discord Embedded App SDK
 * https://github.com/colyseus/colyseus/issues/707
 *
 * All URLs must go through the local proxy from
 * https://<app_id>.discordsays.com/<backend>/...
 *
 * You must configure your URL Mappings with:
 * - /colyseus/{subdomain} -> {subdomain}.colyseus.cloud
 *
 * Example:
 *  const client = new Client("https://xxxx.colyseus.cloud");
 *
 */
export declare function discordURLBuilder(url: URL): string;
